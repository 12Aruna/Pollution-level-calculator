const calculateAQI = require("./aqi-calculator");
module.exports = calculateAQI;
